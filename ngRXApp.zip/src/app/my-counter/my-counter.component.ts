import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { increment, decrement, reset } from '../counter.actions';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-my-counter',
  templateUrl: './my-counter.component.html',
})
export class MyCounterComponent {
    count$: Observable<number>;
 
    constructor(private store: Store<{ count: number }>) {
      this.count$ = store.select('count');
    }
   
    increment() {
      this.store.dispatch(increment());
    }
   
    decrement() {
      this.store.dispatch(decrement());
    }
   
    reset() {
      this.store.dispatch(reset());
    }

    switch(){
      let srcObservable= of(1,2,3,4)
      let innerObservable= of('A','B','C','D')
       
      srcObservable.pipe(
        switchMap( val => {
          console.log('Source value '+val)
          console.log('starting new observable')
          return innerObservable
        })
      )
      .subscribe(ret=> {
        console.log('Recd ' + ret);
      })

    }

}