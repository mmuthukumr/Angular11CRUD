import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, timer } from 'rxjs';
import { catchError, tap, delay } from 'rxjs/operators';


const apiUrl = 'http://dummy.restapiexample.com/api/v1/employees';
const apiUrl2 = 'http://dummy.restapiexample.com/api/v1/employee';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  constructor(private http: HttpClient) { }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  getProducts(): Observable<any[]> {
    return this.http.get<any[]>(apiUrl)
      .pipe(
        tap((product) => console.log('fetched products' + product)),
        catchError(this.handleError('getProducts', []))
      );
  }

  // getProduct(id: number): Observable<any> {
  //   const url = `${apiUrl2}/${id}`;
  //   return this.http.get<any>(url).pipe(
  //     tap(_ => console.log(`fetched product id=${id}`)),
  //     catchError(this.handleError<any>(`getProduct id=${id}`))
  //   );
  // }
}
