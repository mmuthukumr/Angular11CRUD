import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, Observable, of, Subject, timer } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { ProductService } from '../services/product.service';
const source = timer(1000, 2000);
const subscribe = source.subscribe(val => console.log(val));

const myObservable = of('apple', 'orange', 'grappe');
const myObserver = {
  next: (x: string) => { }, //console.log('Observer got a next value: ' + x),
  error: (err: string) => console.error('Observer got an error: ' + err),
  //complete: () => console.log('Observer got a complete notification'),
};

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
const apiUrl = 'http://dummy.restapiexample.com/api/v1/employees';
const apiUrl2 = 'http://dummy.restapiexample.com/api/v1/employee';
@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})

export class SecondComponent implements OnInit {
  data: any[] = [];
  id: number = 1;
  subject: any;
  bSubject: any;
  constructor(private http: HttpClient, private productService: ProductService) {
    myObservable.subscribe(myObserver => console.log(myObserver));

    this.productService.getProducts()
      .subscribe((res: any) => {
        this.data = res;
        //console.log(this.data);
      }, err => {
        console.log(err);
      });

    // this.productService.getProduct(this.id)
    //   .subscribe((res: any) => {
    //     this.data = res;
    //     //console.log(this.data);
    //   }, err => {
    //     console.log(err);
    //   });
  }
  /* private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  } */
  ngOnInit(): void {
    setTimeout(() => { subscribe.unsubscribe(); }, 12000);

    // Behavior Subject

    // a is an initial value. if there is a subscription 
    // after this, it would get "a" value immediately
    /*  this.bSubject = new BehaviorSubject("a");
     this.bSubject.next("b");
     this.bSubject.next("k"); // Subscription got c
 
     this.bSubject.subscribe((value: any) => {
       console.log("Subscription got", value); // Subscription got b, 
       // ^ This would not happen 
       // for a generic observable 
       // or generic subject by default
     }); */


    /* this.bSubject.next("c"); // Subscription got c
    this.bSubject.next("d"); // Subscription got d */

    // Regular Subject
    /* this.subject = new Subject();


    this.subject.next("b");
    this.subject.next("x"); // Subscription got c

    this.subject.subscribe((value: any) => {
      console.log("Subscription got", value); // Subscription wont get 
      // anything at this point
    });

    this.subject.next("z"); // Subscription got c
    this.subject.next("c"); // Subscription got c
    this.subject.next("d"); // Subscription got d */

  }

  time = new Observable<string>(observer => {
    setInterval(() => observer.next(new Date().toString()), 1000);
  });

  onSubjectClick(): any {
    //this.subject.next("d"); // Subscription got d
    this.bSubject.next("d"); // Subscription got d
  }

}
