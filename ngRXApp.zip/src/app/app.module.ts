import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StoreModule } from '@ngrx/store';
import { counterReducer } from './counter.reducer';
import { MyCounterComponent } from './my-counter/my-counter.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ZippyComponent } from './first/zippy/zippy.component';
debugger;
@NgModule({
  declarations: [
    AppComponent, MyCounterComponent, FirstComponent, SecondComponent, PagenotfoundComponent, ZippyComponent,
  ],
  imports: [ 
    BrowserModule, HttpClientModule,
    AppRoutingModule, StoreModule.forRoot({ count: counterReducer })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
