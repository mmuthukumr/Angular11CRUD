import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {

  currentitem:string = '';
  miss:string = '';
  constructor() { }
  ngOnInit(): void {
    this.miss = 'Television';
    this.currentitem = 'Television';
  }
  onClose(newItem: string): void{

  }
  onOpen(openItem: string): void{

  }
  itemChange(): void{
    this.currentitem = 'Laptop';
  }
}
