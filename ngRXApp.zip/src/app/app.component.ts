import { Component } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {Game} from '../app/game';

debugger;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  name: any = '';
  constructor( private route: ActivatedRoute){  }
  title = 'ngRXApp';
  games: Game[] = [];
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.name = params['name'];
      
    });
  }
}
